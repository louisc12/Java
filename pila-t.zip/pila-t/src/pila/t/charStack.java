/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pila.t;

/**
 *
 * @author louiscarrillo
 */
public class charStack {
    private char[] data;
    private int pointer;


    public charStack(int size){
        this.data = new char[size];
        pointer = -1;
    }

    public boolean push(char value){
        if (pointer < (data.length - 1)){
            pointer ++;
            data[pointer] = value;
            return true;
        }
        return false;
    }
    
    public char pop(){
        if (pointer >= 0){
            return data[pointer--];
        }
        return '\0';
    }
    
    public char peek(){
        if (pointer >= 0){
            return data[pointer];
        }
        return '\0';
    }

    public boolean EstaVacia(){
        return (pointer < 0);
    }
}
