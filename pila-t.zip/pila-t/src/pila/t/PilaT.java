/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pila.t;

/**
 *
 * @author louiscarrillo
 */
public class PilaT {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
          //Probar el metodo convertirInfijaAPrefija con los siguientes valores
        //X+Y/Z+X -> XYZ/+X+
        //A+B+C   -> AB+C+
        //X+Y^Z*T -> XYZ^T*+
        
        
       
        
    }
    public static String convertirInfijaAPostfija(String entrada){
        String salida = "";
        charStack pilaOperadores = new charStack(entrada.length()); 
        
        int longitud = entrada.length();
        
        //Recorrer la cadena de entrada caracter a caracter
        for(int i = 0;i < longitud;i++){
            //Asignar el caracter actual a una variable
            char actual = entrada.charAt(i);
        
            //Si Es operando
            if (esOperando(actual)){
                //Agregar el operando a la cadena de salida
                salida = salida + actual;
            }
            
                
                
                
            //Si es operandor
                //Mientras la pila se encuentre vacía
                //Sacar todos los operadores de la pila que tengan mayor
                //prioridad que el operador actual y añadirlos a la salida
                //-
                while(!pilaOperadores.EstaVacia()){
                    if(prioridad(pilaOperadores[i]) > esOperador(actual) ){
                        pilaOperadores.pop();
                        
                        salida = salida + actual;
                        
                        
                        
                        
                        //-
                        //Agregar el operador a la pila
                        pilaOperadores.push(actual);
                    }
            //Si es un caracter no reconocido
                //Devolver "error"
                    else{
                        System.out.println("error");
                    }
                }
                
        }
        
        //Agregar todos los operadores que se encuentren la pila
        salida = salida + pilaOperadores;
        
        
        return salida;
    }
    
    public static boolean esOperando(char simbolo){
        return Character.isLetter(simbolo);
    }
    public static boolean esOperador(char simbolo){
        return (simbolo == '+') ||
               (simbolo == '-') ||
               (simbolo == '*') ||
               (simbolo == '/') ||
               (simbolo == '^');
    }
    public static byte prioridad(char operador){
        switch (operador) {
            case '+':
            case '-':
                return 0;
            case '*':
            case '/':
                return 1;
            case '^':
                return 2;
            default:
                return -1;
        }
    }
    
}





